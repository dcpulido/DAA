package es.uvigo.esei.daa.listeners;

public enum DbManagementAction {
	DROP_CREATE_DROP, CREATE_DROP, ONLY_CREATE, ONLY_DROP;
}
